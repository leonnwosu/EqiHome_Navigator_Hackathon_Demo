import NeighborhoodDetail from '../../pages/NeighborhoodDetail'

export default function NeighborhoodDetailExample() {
  return <NeighborhoodDetail />
}
