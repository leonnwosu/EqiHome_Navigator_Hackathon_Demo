import ScoreDisplay from '../ScoreDisplay'

export default function ScoreDisplayExample() {
  return (
    <div className="space-y-4 p-6 max-w-md">
      <ScoreDisplay label="Affordability" score={85} color="primary" />
      <ScoreDisplay label="Program Access" score={72} color="accent" />
      <ScoreDisplay label="Wealth Building" score={91} color="chart-2" />
      <ScoreDisplay label="Stability" score={68} color="chart-3" />
    </div>
  )
}
