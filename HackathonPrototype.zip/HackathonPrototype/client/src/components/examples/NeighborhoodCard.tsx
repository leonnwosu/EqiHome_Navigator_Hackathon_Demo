import NeighborhoodCard from '../NeighborhoodCard'
import suburbanImage from '@assets/generated_images/suburban_neighborhood_aerial_view.png'

export default function NeighborhoodCardExample() {
  return (
    <div className="max-w-md p-4">
      <NeighborhoodCard
        id="1"
        name="Greenwood Heights"
        city="Portland"
        state="OR"
        image={suburbanImage}
        affordabilityScore={85}
        programAccessScore={72}
        wealthBuildingScore={91}
        stabilityScore={68}
        medianPrice="$425K"
        programsAvailable={8}
        appreciationRate="+4.2%"
        onViewDetails={(id) => console.log('View details:', id)}
      />
    </div>
  )
}
