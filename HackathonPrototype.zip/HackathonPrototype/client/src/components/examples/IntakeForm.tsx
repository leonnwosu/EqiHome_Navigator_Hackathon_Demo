import IntakeForm from '../../pages/IntakeForm'

export default function IntakeFormExample() {
  return <IntakeForm />
}
