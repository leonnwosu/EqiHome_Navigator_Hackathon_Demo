import ProgramCard from '../ProgramCard'

const mockPrograms = [
  {
    id: '1',
    name: 'First-Time Homebuyer Grant',
    type: 'Down Payment',
    eligibility: 'First-time buyers with household income below $85,000',
    benefit: 'Up to $25,000 in down payment assistance',
    applyUrl: '#'
  },
  {
    id: '2',
    name: 'Low-Interest Mortgage Program',
    type: 'Financing',
    eligibility: 'Buyers purchasing in designated opportunity zones',
    benefit: '2.5% interest rate (3% below market)',
    applyUrl: '#'
  },
  {
    id: '3',
    name: 'Property Tax Relief',
    type: 'Tax Credit',
    eligibility: 'New homeowners in revitalization districts',
    benefit: '50% property tax reduction for 5 years',
  }
]

export default function ProgramCardExample() {
  return (
    <div className="max-w-2xl p-6">
      <ProgramCard programs={mockPrograms} />
    </div>
  )
}
