import { Home } from "lucide-react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import ThemeToggle from "./ThemeToggle";

export default function Navigation() {
  const [location] = useLocation();

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 flex h-16 items-center justify-between">
        <Link href="/" className="flex items-center gap-2 hover-elevate px-2 py-1 rounded-md" data-testid="link-home">
          <Home className="h-6 w-6 text-primary" />
          <span className="font-serif text-xl font-semibold">EquiHome Navigator</span>
        </Link>

        <nav className="hidden md:flex items-center gap-6">
          <Link href="/" data-testid="link-nav-home">
            <Button variant={location === "/" ? "secondary" : "ghost"}>
              Home
            </Button>
          </Link>
          <Link href="/get-started" data-testid="link-nav-get-started">
            <Button variant={location === "/get-started" ? "secondary" : "ghost"}>
              Get Started
            </Button>
          </Link>
          <Link href="/dashboard" data-testid="link-nav-dashboard">
            <Button variant={location === "/dashboard" ? "secondary" : "ghost"}>
              Dashboard
            </Button>
          </Link>
        </nav>

        <div className="flex items-center gap-2">
          <ThemeToggle />
          <Link href="/get-started" data-testid="link-cta-get-started">
            <Button>Find Your Home</Button>
          </Link>
        </div>
      </div>
    </header>
  );
}
