import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bookmark, MapPin } from "lucide-react";
import ScoreDisplay from "./ScoreDisplay";

interface NeighborhoodCardProps {
  id: string;
  name: string;
  city: string;
  state: string;
  image: string;
  affordabilityScore: number;
  programAccessScore: number;
  wealthBuildingScore: number;
  stabilityScore: number;
  medianPrice: string;
  programsAvailable: number;
  appreciationRate: string;
  onViewDetails: (id: string) => void;
}

export default function NeighborhoodCard({
  id,
  name,
  city,
  state,
  image,
  affordabilityScore,
  programAccessScore,
  wealthBuildingScore,
  stabilityScore,
  medianPrice,
  programsAvailable,
  appreciationRate,
  onViewDetails,
}: NeighborhoodCardProps) {
  return (
    <Card className="hover-elevate overflow-hidden" data-testid={`card-neighborhood-${id}`}>
      <div className="aspect-video w-full overflow-hidden">
        <img
          src={image}
          alt={`${name} neighborhood`}
          className="w-full h-full object-cover"
        />
      </div>
      <CardHeader className="space-y-1">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1">
            <h3 className="text-xl font-semibold" data-testid={`text-neighborhood-name-${id}`}>{name}</h3>
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <MapPin className="h-4 w-4" />
              <span>{city}, {state}</span>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            data-testid={`button-save-${id}`}
            onClick={() => console.log(`Saved ${name}`)}
          >
            <Bookmark className="h-5 w-5" />
          </Button>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="space-y-3">
          <ScoreDisplay label="Affordability" score={affordabilityScore} color="primary" />
          <ScoreDisplay label="Program Access" score={programAccessScore} color="accent" />
          <ScoreDisplay label="Wealth Building" score={wealthBuildingScore} color="chart-2" />
          <ScoreDisplay label="Stability" score={stabilityScore} color="chart-3" />
        </div>

        <div className="grid grid-cols-2 gap-4 pt-4 border-t">
          <div>
            <div className="text-sm text-muted-foreground">Median Price</div>
            <div className="text-lg font-semibold" data-testid={`text-median-price-${id}`}>{medianPrice}</div>
          </div>
          <div>
            <div className="text-sm text-muted-foreground">Programs</div>
            <div className="text-lg font-semibold">{programsAvailable}</div>
          </div>
          <div>
            <div className="text-sm text-muted-foreground">Appreciation</div>
            <div className="text-lg font-semibold text-chart-2">{appreciationRate}</div>
          </div>
          <div>
            <div className="text-sm text-muted-foreground">Match</div>
            <Badge variant="secondary" className="text-sm">
              {Math.round((affordabilityScore + programAccessScore + wealthBuildingScore + stabilityScore) / 4)}%
            </Badge>
          </div>
        </div>
      </CardContent>

      <CardFooter>
        <Button
          className="w-full"
          variant="outline"
          onClick={() => onViewDetails(id)}
          data-testid={`button-view-details-${id}`}
        >
          View Details
        </Button>
      </CardFooter>
    </Card>
  );
}
