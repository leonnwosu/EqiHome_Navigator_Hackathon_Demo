import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ExternalLink } from "lucide-react";

interface Program {
  id: string;
  name: string;
  type: string;
  eligibility: string;
  benefit: string;
  applyUrl?: string;
}

interface ProgramCardProps {
  programs: Program[];
}

export default function ProgramCard({ programs }: ProgramCardProps) {
  return (
    <Accordion type="single" collapsible className="w-full">
      {programs.map((program) => (
        <AccordionItem key={program.id} value={program.id} data-testid={`program-${program.id}`}>
          <AccordionTrigger className="hover:no-underline">
            <div className="flex items-center gap-3 text-left flex-wrap">
              <span className="font-semibold">{program.name}</span>
              <Badge variant="secondary">{program.type}</Badge>
            </div>
          </AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4 pt-2">
              <div>
                <h4 className="text-sm font-medium text-muted-foreground mb-1">
                  Eligibility
                </h4>
                <p className="text-sm leading-relaxed">{program.eligibility}</p>
              </div>
              <div>
                <h4 className="text-sm font-medium text-muted-foreground mb-1">
                  Benefit
                </h4>
                <p className="text-sm leading-relaxed text-chart-2 font-medium">
                  {program.benefit}
                </p>
              </div>
              {program.applyUrl && (
                <Button
                  variant="outline"
                  size="sm"
                  className="gap-2"
                  onClick={() => window.open(program.applyUrl, '_blank')}
                  data-testid={`button-apply-${program.id}`}
                >
                  Learn More & Apply
                  <ExternalLink className="h-4 w-4" />
                </Button>
              )}
            </div>
          </AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  );
}
