import { Progress } from "@/components/ui/progress";

interface ScoreDisplayProps {
  label: string;
  score: number;
  color?: "primary" | "accent" | "chart-2" | "chart-3";
}

export default function ScoreDisplay({ label, score, color = "primary" }: ScoreDisplayProps) {
  const getColorClass = () => {
    switch (color) {
      case "accent":
        return "text-accent";
      case "chart-2":
        return "text-chart-2";
      case "chart-3":
        return "text-chart-3";
      default:
        return "text-primary";
    }
  };

  return (
    <div className="space-y-2" data-testid={`score-${label.toLowerCase().replace(/\s+/g, '-')}`}>
      <div className="flex justify-between items-baseline">
        <span className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
          {label}
        </span>
        <span className={`text-2xl font-bold ${getColorClass()}`}>
          {score}
        </span>
      </div>
      <Progress value={score} className="h-2" />
    </div>
  );
}
