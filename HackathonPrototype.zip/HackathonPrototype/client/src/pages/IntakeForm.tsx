import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { useLocation } from "wouter";

const formSchema = z.object({
  income: z.number().min(10000).max(1000000),
  creditRange: z.string().min(1),
  familySize: z.number().min(1).max(10),
  budget: z.number().min(50000).max(5000000),
  location: z.string().min(1),
  race: z.string().optional(),
  shareRace: z.boolean().default(false),
});

type FormData = z.infer<typeof formSchema>;

export default function IntakeForm() {
  const [step, setStep] = useState(1);
  const [, setLocation] = useLocation();
  const totalSteps = 3;

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      income: 75000,
      creditRange: "",
      familySize: 2,
      budget: 350000,
      location: "",
      race: "",
      shareRace: false,
    },
  });

  const onSubmit = (data: FormData) => {
    console.log("Form submitted:", data);
    setLocation("/dashboard");
  };

  const nextStep = () => {
    if (step < totalSteps) setStep(step + 1);
  };

  const prevStep = () => {
    if (step > 1) setStep(step - 1);
  };

  const progress = (step / totalSteps) * 100;

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4 max-w-2xl">
        <div className="mb-8">
          <h1 className="font-serif text-4xl font-semibold mb-2" data-testid="text-form-heading">
            Let's Find Your Perfect Neighborhood
          </h1>
          <p className="text-muted-foreground">
            Answer a few questions to get personalized recommendations
          </p>
        </div>

        <div className="mb-6">
          <div className="flex justify-between text-sm text-muted-foreground mb-2">
            <span>Step {step} of {totalSteps}</span>
            <span>{Math.round(progress)}% Complete</span>
          </div>
          <Progress value={progress} />
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <Card>
              <CardHeader>
                <CardTitle>
                  {step === 1 && "Basic Information"}
                  {step === 2 && "Financial Profile"}
                  {step === 3 && "Preferences"}
                </CardTitle>
                <CardDescription>
                  {step === 1 && "Tell us about your household"}
                  {step === 2 && "Help us understand your budget"}
                  {step === 3 && "Optional: Share additional details for better recommendations"}
                </CardDescription>
              </CardHeader>

              <CardContent className="space-y-6">
                {step === 1 && (
                  <>
                    <FormField
                      control={form.control}
                      name="familySize"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Family Size</FormLabel>
                          <FormControl>
                            <div className="space-y-4">
                              <Slider
                                min={1}
                                max={10}
                                step={1}
                                value={[field.value]}
                                onValueChange={(value) => field.onChange(value[0])}
                                data-testid="slider-family-size"
                              />
                              <div className="text-center">
                                <span className="text-2xl font-bold" data-testid="text-family-size-value">
                                  {field.value} {field.value === 1 ? "person" : "people"}
                                </span>
                              </div>
                            </div>
                          </FormControl>
                          <FormDescription>
                            Number of people who will be living in the home
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Preferred Location</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-location">
                                <SelectValue placeholder="Select a state or region" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="pacific-nw">Pacific Northwest</SelectItem>
                              <SelectItem value="california">California</SelectItem>
                              <SelectItem value="southwest">Southwest</SelectItem>
                              <SelectItem value="midwest">Midwest</SelectItem>
                              <SelectItem value="northeast">Northeast</SelectItem>
                              <SelectItem value="southeast">Southeast</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormDescription>
                            Which region are you interested in?
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </>
                )}

                {step === 2 && (
                  <>
                    <FormField
                      control={form.control}
                      name="income"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Annual Household Income</FormLabel>
                          <FormControl>
                            <div className="space-y-4">
                              <Slider
                                min={10000}
                                max={200000}
                                step={5000}
                                value={[field.value]}
                                onValueChange={(value) => field.onChange(value[0])}
                                data-testid="slider-income"
                              />
                              <div className="text-center">
                                <span className="text-2xl font-bold" data-testid="text-income-value">
                                  ${field.value.toLocaleString()}
                                </span>
                              </div>
                            </div>
                          </FormControl>
                          <FormDescription>
                            Your total household income helps us find affordable options
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="creditRange"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Credit Score Range</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-credit">
                                <SelectValue placeholder="Select your credit range" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="excellent">Excellent (750+)</SelectItem>
                              <SelectItem value="good">Good (700-749)</SelectItem>
                              <SelectItem value="fair">Fair (650-699)</SelectItem>
                              <SelectItem value="poor">Building (below 650)</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormDescription>
                            This helps us match you with appropriate financing programs
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="budget"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Maximum Budget</FormLabel>
                          <FormControl>
                            <div className="space-y-4">
                              <Slider
                                min={50000}
                                max={1000000}
                                step={25000}
                                value={[field.value]}
                                onValueChange={(value) => field.onChange(value[0])}
                                data-testid="slider-budget"
                              />
                              <div className="text-center">
                                <span className="text-2xl font-bold" data-testid="text-budget-value">
                                  ${field.value.toLocaleString()}
                                </span>
                              </div>
                            </div>
                          </FormControl>
                          <FormDescription>
                            What's the most you're comfortable spending on a home?
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </>
                )}

                {step === 3 && (
                  <>
                    <div className="bg-muted/50 p-4 rounded-lg space-y-4">
                      <FormField
                        control={form.control}
                        name="shareRace"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                                data-testid="checkbox-share-race"
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                Share demographic information (optional)
                              </FormLabel>
                              <FormDescription>
                                This helps us identify and address systemic barriers in
                                housing access. Your information is private and never used
                                for discriminatory purposes.
                              </FormDescription>
                            </div>
                          </FormItem>
                        )}
                      />

                      {form.watch("shareRace") && (
                        <FormField
                          control={form.control}
                          name="race"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Race/Ethnicity</FormLabel>
                              <Select onValueChange={field.onChange} value={field.value}>
                                <FormControl>
                                  <SelectTrigger data-testid="select-race">
                                    <SelectValue placeholder="Select (optional)" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="prefer-not">Prefer not to say</SelectItem>
                                  <SelectItem value="black">Black or African American</SelectItem>
                                  <SelectItem value="hispanic">Hispanic or Latino</SelectItem>
                                  <SelectItem value="asian">Asian</SelectItem>
                                  <SelectItem value="white">White</SelectItem>
                                  <SelectItem value="native">Native American or Alaska Native</SelectItem>
                                  <SelectItem value="pacific">Native Hawaiian or Pacific Islander</SelectItem>
                                  <SelectItem value="other">Other</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      )}
                    </div>

                    <div className="bg-primary/5 p-4 rounded-lg">
                      <p className="text-sm leading-relaxed">
                        By submitting this form, you'll receive personalized neighborhood
                        recommendations based on affordability, program access, and
                        wealth-building potential. We'll never share your information with
                        third parties.
                      </p>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            <div className="flex justify-between mt-6">
              <Button
                type="button"
                variant="outline"
                onClick={prevStep}
                disabled={step === 1}
                data-testid="button-previous"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Previous
              </Button>

              {step < totalSteps ? (
                <Button type="button" onClick={nextStep} data-testid="button-next">
                  Next
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              ) : (
                <Button type="submit" data-testid="button-submit">
                  Get Recommendations
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              )}
            </div>
          </form>
        </Form>
      </div>
    </div>
  );
}
