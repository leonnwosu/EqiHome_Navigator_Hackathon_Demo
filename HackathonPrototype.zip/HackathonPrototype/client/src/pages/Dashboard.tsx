import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Search, SlidersHorizontal, Sparkles } from "lucide-react";
import NeighborhoodCard from "@/components/NeighborhoodCard";
import { useLocation } from "wouter";
import suburbanImage from "@assets/generated_images/suburban_neighborhood_aerial_view.png";
import urbanImage from "@assets/generated_images/urban_mixed-use_neighborhood.png";
import downtownImage from "@assets/generated_images/downtown_main_street_scene.png";

//todo: remove mock functionality
const mockNeighborhoods = [
  {
    id: "1",
    name: "Greenwood Heights",
    city: "Portland",
    state: "OR",
    image: suburbanImage,
    affordabilityScore: 85,
    programAccessScore: 72,
    wealthBuildingScore: 91,
    stabilityScore: 68,
    medianPrice: "$425K",
    programsAvailable: 8,
    appreciationRate: "+4.2%",
  },
  {
    id: "2",
    name: "Riverside District",
    city: "Eugene",
    state: "OR",
    image: urbanImage,
    affordabilityScore: 92,
    programAccessScore: 85,
    wealthBuildingScore: 78,
    stabilityScore: 81,
    medianPrice: "$315K",
    programsAvailable: 12,
    appreciationRate: "+3.8%",
  },
  {
    id: "3",
    name: "Heritage Park",
    city: "Salem",
    state: "OR",
    image: downtownImage,
    affordabilityScore: 78,
    programAccessScore: 68,
    wealthBuildingScore: 85,
    stabilityScore: 75,
    medianPrice: "$385K",
    programsAvailable: 6,
    appreciationRate: "+5.1%",
  },
];

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [priceRange, setPriceRange] = useState([50000, 1000000]);

  const handleViewDetails = (id: string) => {
    console.log("View neighborhood details:", id);
    setLocation(`/neighborhood/${id}`);
  };

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        <div className="mb-8">
          <div className="flex items-start gap-3 mb-4">
            <Sparkles className="h-8 w-8 text-primary mt-1" />
            <div>
              <h1 className="font-serif text-4xl font-semibold mb-2" data-testid="text-dashboard-heading">
                Your Personalized Recommendations
              </h1>
              <p className="text-lg text-muted-foreground">
                Based on your profile: $75K income, Family of 2, $350K budget
              </p>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-4 gap-6">
          <aside className="lg:col-span-1 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <SlidersHorizontal className="h-5 w-5" />
                  Filters
                </CardTitle>
                <CardDescription>Refine your search</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <label className="text-sm font-medium mb-2 block">Search</label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="City or neighborhood..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-9"
                      data-testid="input-search"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium mb-3 block">
                    Price Range
                  </label>
                  <Slider
                    min={50000}
                    max={1000000}
                    step={25000}
                    value={priceRange}
                    onValueChange={setPriceRange}
                    className="mb-3"
                    data-testid="slider-price-range"
                  />
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>${(priceRange[0] / 1000).toFixed(0)}K</span>
                    <span>${(priceRange[1] / 1000).toFixed(0)}K</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium block">Quick Filters</label>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary" className="cursor-pointer hover-elevate" data-testid="badge-first-time">
                      First-time buyer programs
                    </Badge>
                    <Badge variant="secondary" className="cursor-pointer hover-elevate" data-testid="badge-low-down">
                      Low down payment
                    </Badge>
                    <Badge variant="secondary" className="cursor-pointer hover-elevate" data-testid="badge-appreciation">
                      High appreciation
                    </Badge>
                  </div>
                </div>

                <Button variant="outline" className="w-full" data-testid="button-clear-filters">
                  Clear All Filters
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="text-sm text-muted-foreground">Matches Found</div>
                  <div className="text-2xl font-bold" data-testid="text-matches-count">
                    {mockNeighborhoods.length}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Avg. Match Score</div>
                  <div className="text-2xl font-bold text-chart-2">82%</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Programs Available</div>
                  <div className="text-2xl font-bold text-accent">26</div>
                </div>
              </CardContent>
            </Card>
          </aside>

          <main className="lg:col-span-3 space-y-6">
            <div className="bg-primary/5 p-4 rounded-lg flex items-start gap-3">
              <Sparkles className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
              <div className="text-sm leading-relaxed">
                <strong>AI Insight:</strong> These neighborhoods offer strong affordability
                and wealth-building potential for your profile. We've prioritized areas
                with multiple first-time buyer programs and stable property values.
              </div>
            </div>

            <div className="space-y-6">
              {mockNeighborhoods.map((neighborhood) => (
                <NeighborhoodCard
                  key={neighborhood.id}
                  {...neighborhood}
                  onViewDetails={handleViewDetails}
                />
              ))}
            </div>

            {mockNeighborhoods.length === 0 && (
              <Card>
                <CardContent className="py-12 text-center">
                  <p className="text-muted-foreground">
                    No neighborhoods match your current filters. Try adjusting your
                    search criteria.
                  </p>
                </CardContent>
              </Card>
            )}
          </main>
        </div>
      </div>
    </div>
  );
}
