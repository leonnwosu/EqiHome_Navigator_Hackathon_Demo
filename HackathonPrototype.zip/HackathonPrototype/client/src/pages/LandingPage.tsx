import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { Home, TrendingUp, Shield, Users, ArrowRight, CheckCircle } from "lucide-react";
import heroImage from "@assets/generated_images/family_with_house_keys.png";

export default function LandingPage() {
  return (
    <div className="min-h-screen">
      <section className="relative overflow-hidden py-20 md:py-32">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <Badge variant="secondary" className="text-sm">
                Powered by AI
              </Badge>
              <h1 className="font-serif text-4xl md:text-5xl font-semibold leading-tight" data-testid="text-hero-heading">
                Find Neighborhoods Where You Can Build Real Wealth
              </h1>
              <p className="text-lg leading-relaxed text-muted-foreground">
                EquiHome Navigator uses AI to guide you to communities where you can
                realistically afford a home, access buyer programs, and build
                generational wealth—without the systemic barriers.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link href="/get-started">
                  <Button size="lg" className="gap-2" data-testid="button-get-started-hero">
                    Get Started Free
                    <ArrowRight className="h-5 w-5" />
                  </Button>
                </Link>
                <Link href="/dashboard">
                  <Button size="lg" variant="outline" data-testid="button-view-example">
                    View Example
                  </Button>
                </Link>
              </div>
              <div className="flex items-center gap-4 pt-4">
                <div className="flex -space-x-2">
                  <div className="h-8 w-8 rounded-full bg-primary border-2 border-background" />
                  <div className="h-8 w-8 rounded-full bg-accent border-2 border-background" />
                  <div className="h-8 w-8 rounded-full bg-chart-2 border-2 border-background" />
                </div>
                <p className="text-sm text-muted-foreground">
                  Serving <span className="font-semibold text-foreground">10,000+</span> aspiring homeowners
                </p>
              </div>
            </div>
            <div className="relative">
              <img
                src={heroImage}
                alt="Happy family with house keys"
                className="rounded-lg w-full shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-serif text-3xl font-semibold mb-4">
              How It Works
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Our AI-powered platform analyzes your profile and matches you with
              neighborhoods where you can thrive.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card>
              <CardContent className="p-6 space-y-4">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Users className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold">Share Your Profile</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Tell us about your income, credit, family size, and budget. Your data
                  stays private and secure.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 space-y-4">
                <div className="h-12 w-12 rounded-lg bg-accent/10 flex items-center justify-center">
                  <TrendingUp className="h-6 w-6 text-accent" />
                </div>
                <h3 className="text-xl font-semibold">Get AI Recommendations</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Our scoring engine ranks neighborhoods by affordability, program access,
                  and wealth-building potential.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 space-y-4">
                <div className="h-12 w-12 rounded-lg bg-chart-2/10 flex items-center justify-center">
                  <Home className="h-6 w-6 text-chart-2" />
                </div>
                <h3 className="text-xl font-semibold">Find Your Home</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Explore neighborhoods, understand programs, and connect with
                  equity-focused real estate agents.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="font-serif text-3xl font-semibold mb-4">
                Transparency You Can Trust
              </h2>
              <p className="text-lg text-muted-foreground">
                We expose systemic barriers—not hide them.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="flex gap-4">
                <CheckCircle className="h-6 w-6 text-chart-2 flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-semibold mb-2">Fair Housing Commitment</h4>
                  <p className="text-sm text-muted-foreground">
                    Our recommendations are driven by your priorities—never by race or
                    protected characteristics.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <CheckCircle className="h-6 w-6 text-chart-2 flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-semibold mb-2">Clear Program Summaries</h4>
                  <p className="text-sm text-muted-foreground">
                    No jargon. We explain buyer assistance programs in plain language so
                    you know what you qualify for.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <CheckCircle className="h-6 w-6 text-chart-2 flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-semibold mb-2">Real Wealth Analysis</h4>
                  <p className="text-sm text-muted-foreground">
                    See appreciation trends, stability scores, and displacement risk—not
                    just prices.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <CheckCircle className="h-6 w-6 text-chart-2 flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-semibold mb-2">Privacy Protected</h4>
                  <p className="text-sm text-muted-foreground">
                    Your financial and demographic information is encrypted and never sold
                    to third parties.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-primary/5">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <Shield className="h-12 w-12 text-primary mx-auto" />
            <h2 className="font-serif text-3xl font-semibold">
              Equal Housing Opportunity
            </h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              EquiHome Navigator is committed to fair housing practices. We comply with
              federal and state fair housing laws and do not discriminate based on race,
              color, religion, sex, national origin, familial status, or disability.
            </p>
            <Link href="/get-started">
              <Button size="lg" data-testid="button-get-started-footer">
                Start Your Journey
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
