import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, MapPin, Sparkles, TrendingUp, Users, DollarSign } from "lucide-react";
import { Link, useRoute } from "wouter";
import ScoreDisplay from "@/components/ScoreDisplay";
import ProgramCard from "@/components/ProgramCard";
import suburbanImage from "@assets/generated_images/suburban_neighborhood_aerial_view.png";

//todo: remove mock functionality
const mockPrograms = [
  {
    id: "1",
    name: "First-Time Homebuyer Grant",
    type: "Down Payment",
    eligibility: "First-time buyers with household income below $85,000",
    benefit: "Up to $25,000 in down payment assistance",
    applyUrl: "#",
  },
  {
    id: "2",
    name: "Low-Interest Mortgage Program",
    type: "Financing",
    eligibility: "Buyers purchasing in designated opportunity zones",
    benefit: "2.5% interest rate (3% below market)",
    applyUrl: "#",
  },
  {
    id: "3",
    name: "Property Tax Relief",
    type: "Tax Credit",
    eligibility: "New homeowners in revitalization districts",
    benefit: "50% property tax reduction for 5 years",
  },
];

export default function NeighborhoodDetail() {
  const [match, params] = useRoute("/neighborhood/:id");
  const neighborhoodId = params?.id || "1";

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4 max-w-6xl">
        <Link href="/dashboard">
          <Button variant="ghost" className="mb-6 gap-2" data-testid="button-back">
            <ArrowLeft className="h-4 w-4" />
            Back to Dashboard
          </Button>
        </Link>

        <div className="mb-6">
          <div className="aspect-video w-full overflow-hidden rounded-lg mb-6">
            <img
              src={suburbanImage}
              alt="Greenwood Heights"
              className="w-full h-full object-cover"
            />
          </div>

          <div className="flex items-start justify-between gap-4 flex-wrap">
            <div>
              <h1 className="font-serif text-4xl font-semibold mb-2" data-testid="text-neighborhood-name">
                Greenwood Heights
              </h1>
              <div className="flex items-center gap-2 text-muted-foreground">
                <MapPin className="h-5 w-5" />
                <span className="text-lg">Portland, OR</span>
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm text-muted-foreground">Overall Match</div>
              <div className="text-4xl font-bold text-primary">82%</div>
            </div>
          </div>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview" data-testid="tab-overview">Overview</TabsTrigger>
            <TabsTrigger value="programs" data-testid="tab-programs">Programs</TabsTrigger>
            <TabsTrigger value="market" data-testid="tab-market">Market Data</TabsTrigger>
            <TabsTrigger value="agents" data-testid="tab-agents">Agents</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-primary" />
                  AI Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="leading-relaxed">
                  <strong>Why this neighborhood matches your profile:</strong> Greenwood
                  Heights offers excellent affordability for your $75K income and $350K
                  budget. With a median home price of $425K and 8 first-time buyer
                  assistance programs, you could realistically purchase here with as
                  little as 3-5% down payment.
                </p>
                <p className="leading-relaxed text-muted-foreground">
                  The neighborhood has shown consistent 4.2% annual appreciation over the
                  past 5 years, making it a strong wealth-building opportunity. The area
                  has low displacement risk and diverse demographics, with good schools
                  and access to public transit.
                </p>
              </CardContent>
            </Card>

            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Scores Breakdown</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <ScoreDisplay label="Affordability" score={85} color="primary" />
                  <ScoreDisplay label="Program Access" score={72} color="accent" />
                  <ScoreDisplay label="Wealth Building" score={91} color="chart-2" />
                  <ScoreDisplay label="Stability" score={68} color="chart-3" />
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Key Metrics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Median Home Price</span>
                    <span className="text-lg font-semibold">$425,000</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">5-Year Appreciation</span>
                    <span className="text-lg font-semibold text-chart-2">+4.2%/year</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Property Tax Rate</span>
                    <span className="text-lg font-semibold">1.15%</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Median Rent</span>
                    <span className="text-lg font-semibold">$1,850/mo</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Walk Score</span>
                    <span className="text-lg font-semibold">78/100</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="programs" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Available Assistance Programs</CardTitle>
                <p className="text-sm text-muted-foreground mt-2">
                  Based on your income of $75K and family size of 2, you may qualify for
                  these programs
                </p>
              </CardHeader>
              <CardContent>
                <ProgramCard programs={mockPrograms} />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="market" className="space-y-6">
            <div className="grid md:grid-cols-3 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Price Trend (5yr)
                  </CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-chart-2">+23.1%</div>
                  <p className="text-xs text-muted-foreground">
                    Consistent growth trajectory
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Days on Market
                  </CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">28</div>
                  <p className="text-xs text-muted-foreground">Average listing time</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Price per Sq Ft
                  </CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">$285</div>
                  <p className="text-xs text-muted-foreground">12% below metro avg</p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Market Analysis</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">Current Market Conditions</h4>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Greenwood Heights is currently a balanced market with moderate
                    inventory levels. Home prices have increased steadily but remain below
                    the metro average, making this an opportune time to enter the market.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Future Outlook</h4>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Planned infrastructure improvements including a new light rail station
                    and mixed-use development are expected to boost property values over
                    the next 3-5 years. School district ratings have improved
                    significantly.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="agents" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Equity-Focused Agents</CardTitle>
                <p className="text-sm text-muted-foreground mt-2">
                  These agents specialize in fair housing and helping first-time buyers
                </p>
              </CardHeader>
              <CardContent className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div
                    key={i}
                    className="flex items-center gap-4 p-4 rounded-lg border hover-elevate"
                    data-testid={`agent-${i}`}
                  >
                    <div className="h-16 w-16 rounded-full bg-gradient-to-br from-primary to-accent flex-shrink-0" />
                    <div className="flex-1">
                      <h4 className="font-semibold">Agent Name {i}</h4>
                      <p className="text-sm text-muted-foreground">
                        First-Time Buyer Specialist
                      </p>
                      <div className="flex gap-2 mt-2 flex-wrap">
                        <Badge variant="secondary">Fair Housing Certified</Badge>
                        <Badge variant="secondary">15 years experience</Badge>
                      </div>
                    </div>
                    <Button data-testid={`button-contact-agent-${i}`}>Contact</Button>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
