# EquiHome Navigator Design Guidelines

## Design Approach
**System**: Material Design-inspired with fintech/proptech influences (Zillow, Mint, Linear)
**Rationale**: This is a data-intensive, trust-critical application where clarity, accessibility, and information hierarchy are paramount. Users are making major financial decisions and need confidence in the platform's credibility.

## Typography System

**Font Families**:
- Primary: Inter (via Google Fonts) - UI elements, body text, data displays
- Accent: Lexend (via Google Fonts) - Headlines, section headers

**Hierarchy**:
- Hero Headlines: 3xl to 5xl, Lexend, font-semibold
- Section Headers: 2xl to 3xl, Lexend, font-semibold
- Subsection Headers: xl, Inter, font-semibold
- Body Text: base, Inter, font-normal, leading-relaxed
- Data Labels: sm, Inter, font-medium, uppercase tracking-wide
- Metric Values: 2xl to 3xl, Inter, font-bold
- Helper Text: sm, Inter, font-normal

## Layout System

**Spacing Primitives**: Use Tailwind units of **2, 4, 6, 8, 12, 16**
- Component padding: p-4 or p-6
- Section spacing: py-12 or py-16
- Card gaps: gap-6 or gap-8
- Form field spacing: space-y-4

**Container Strategy**:
- Max-width: max-w-7xl for main content
- Dashboard grids: max-w-screen-2xl
- Form containers: max-w-2xl
- Reading content: max-w-4xl

## Component Library

### Navigation
**Top Navigation Bar**: Fixed header with logo left, navigation center, user profile/CTA right. Height: h-16. Slight shadow/border for depth.

### Hero Section (Landing Page)
**Layout**: Asymmetric two-column (60/40 split)
- Left: Bold headline (Lexend, 4xl), compelling subheadline explaining equity focus, primary CTA ("Get Started" button), trust indicators (e.g., "Serving 10,000+ aspiring homeowners")
- Right: Hero image showing diverse families in front of homes or keys/house imagery conveying hope and ownership
- Background: Subtle gradient or geometric pattern overlay

### Intake Form
**Multi-step Form Design**:
- Progress indicator at top (steps: Basic Info → Financial Profile → Preferences → Submit)
- Card-based sections with generous padding (p-8)
- Input groups with clear labels above fields
- Helper text below inputs explaining why data is needed
- Range sliders for budget with clear min/max labels
- Checkbox for optional race field with privacy explanation
- Large, prominent "Next" and "Back" buttons at bottom

### Dashboard Layout
**Three-Column Grid** (on desktop):
- Left Sidebar (w-64): Filters and refine search options, saved searches
- Main Content (flex-1): Neighborhood recommendation cards in vertical stack
- Right Panel (w-80): Quick stats summary, next steps checklist

**Mobile**: Stack to single column, filters become collapsible drawer

### Neighborhood Recommendation Cards
**Card Structure**:
- Header: Neighborhood name (text-xl, font-semibold), city/state (text-sm)
- Hero Image: Neighborhood photo or map preview (aspect-video, rounded corners)
- Scoring Breakdown: Horizontal progress bars for each metric
  - Affordability Score: width based on percentage
  - Program Access: width based on availability
  - Wealth Building: growth potential indicator
  - Stability Score: displacement risk (inverted color logic)
- Key Metrics Grid: 2x2 grid showing median price, down payment programs available, appreciation rate, diversity index
- CTA: "View Details" button (outline style), "Save" icon button

### Detailed Neighborhood View
**Hero Section**: Full-width map with overlay showing neighborhood boundary
**Tabs Navigation**: Overview | Programs | Market Data | Agents
**Content Sections**:
- AI Summary: Card with robot icon, plain-language explanation of why this area matches
- Program Summaries: Expandable accordion list, each program has title, eligibility summary, link to apply
- Market Metrics: Data visualization with charts (simple bar/line charts)
- Matched Agents: Profile cards with photo, name, specialization, contact button

### Data Visualization
**Score Displays**: 
- Large circular progress indicators for primary scores (0-100 scale)
- Color-coded but NOT specified here (left for color phase)
- Labels outside circles with metric name and numerical value

**Comparison Tables**:
- Sticky header row
- Zebra striping for row differentiation
- Highlight column on hover
- Sort indicators on column headers

### Forms & Inputs
**Text Inputs**: 
- Border-2, rounded-lg, p-3, focus ring
- Label: text-sm, font-medium, mb-2
- Error state: border variant, error text below

**Dropdowns/Selects**: 
- Same styling as text inputs
- Chevron icon right-aligned

**Range Sliders**:
- Track height: h-2, rounded-full
- Thumb: larger circular handle
- Value display above thumb or at endpoints

**Checkboxes/Radio**:
- Size: w-5 h-5
- Label: ml-2, aligned vertically

### Agent Profile Cards
**Layout**: Horizontal card (flex)
- Left: Profile photo (w-20 h-20, rounded-full)
- Center: Name (font-semibold), title, specializations (pills/tags)
- Right: "Contact" button (primary style)

### Trust & Credibility Elements
**Social Proof Banner**: Above footer, featuring user testimonials in cards, statistics (e.g., "Average 15% better outcomes"), partnership logos
**Privacy Indicators**: Lock icons, "Your data is protected" messaging near sensitive fields
**Fair Housing Badge**: Prominent placement with "Equal Housing Opportunity" commitment

## Icons
**Library**: Heroicons (via CDN)
**Usage**: 
- Navigation: 24px icons
- Cards/Actions: 20px icons  
- Inline with text: 16px icons
- Feature highlights: 32px or larger

## Spacing & Rhythm
**Vertical Rhythm**:
- Page sections: py-16 or py-20
- Cards: p-6 or p-8
- Between elements: mb-4, mb-6, mb-8
- Form sections: space-y-6

**Horizontal Grid**:
- Dashboard: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 for metric cards
- Comparison: grid-cols-1 lg:grid-cols-2 for side-by-side
- Always collapse to single column on mobile

## Images
**Hero Image**: Family or individual(s) holding house keys, looking hopeful - diverse representation essential
**Neighborhood Cards**: Street view photos or aerial map views of neighborhoods
**Agent Profiles**: Professional headshots
**Trust Section**: Avoid stock photos, use authentic imagery or abstract graphics
**Placement**: Hero (right side), neighborhood cards (top), scattered throughout for emotional connection

## Accessibility
- All forms use semantic HTML with proper labels
- Minimum touch target: 44x44px for all interactive elements
- Focus indicators on all interactive elements
- ARIA labels for icon-only buttons
- Skip navigation link for keyboard users
- Contrast ratios meet WCAG AA (handled in color phase)

## Animation Philosophy
**Minimal & Purposeful**:
- Page transitions: Simple fade-in
- Card hover: Subtle lift (translate-y-1) and shadow increase
- Loading states: Simple spinner or skeleton screens
- NO scroll animations, parallax, or decorative motion